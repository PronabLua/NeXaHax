#!/bin/sh
PACKAGE_NAME="com.pubg.imobile"


LIB_PATH=$(find /data/app/ -type d -name "*$PACKAGE_NAME*" | head -n 1)/lib/arm64/


if [ -z "$LIB_PATH" ]; then
    echo "Erro: BGMI directory not found!"
    exit 1
fi

if [ ! -d "$LIB_PATH" ]; then
    echo "Error: The Directory $LIB_PATH Does Not Exist!"
    exit 1
fi


cp libGVoicePlugin.so "$LIB_PATH"
chmod 755 "$LIB_PATH/libGVoicePlugin.so"

echo "Library Successfully Installed On: $LIB_PATH"